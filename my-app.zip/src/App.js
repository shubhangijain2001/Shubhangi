import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <p>
          Name <code>is </code> 
          <p> an awesome programmer .</p>
        </p>
        
      </header>
    </div>
  );
}

export default App;
